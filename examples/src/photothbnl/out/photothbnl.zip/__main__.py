# -- coding: utf-8 --
#!/user/bin/env python2.7

from src import photothbnl

if __name__ == '__main__':
    photothbnl.run()