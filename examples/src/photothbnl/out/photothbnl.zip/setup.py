# -- coding: utf-8 --
#!/user/bin/env python2.7

""" 
    pip install -r py.requirements/requirements.txt
    python setup.py clean --all
    python setup.py bdist --format=zip
    python setup.py install --user 

"""

import sys
import os.path
from distutils.core import setup
from setuptools import find_packages, setup
from pathlib import Path

setup(
    name='lambda_thumbnail',
    description='Script for Lambda Function that copies original photo to a Thumbnails Directory within S3',
    author='stanley petaway',
    author_email='stanley.petaway@accenture.com',
    license='MIT',
    instal_requires=[
        "pillow",
    ],
    version='0.0.1',
    py_modules=[
        'photothbnl',
        '__main__',
        '__init__',
    ]
)